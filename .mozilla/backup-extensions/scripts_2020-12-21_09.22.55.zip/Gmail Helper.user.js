// ==UserScript==
// @name        Gmail Helper
// @namespace   Violentmonkey Scripts
// @match       https://mail.google.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 6/18/2020, 1:43:05 PM
// ==/UserScript==

window.selectAll = function () {
  var rows = document.getElementsByName('t')
  for (var i=0; i < rows.length; i++){
    rows[i].checked = !rows[i].checked;
  }
}

window.downloadSelected = function () {
  var rows = document.getElementsByName('t')
  for (var i=0; i < rows.length; i++){
    if (rows[i].checked){
      var mailId = rows[i].getAttribute("value")
      window.downloadMail(mailId)
    }
  }
}

window.selectChange = function (event) {
  if (event.target.value == "download_selected")
    window.downloadSelected()
}


window.downloadMail = function (mailId) {
  var currUser = window.location.href.split("/")[5]
  window.open("/mail/u/" + currUser + "?view=att&th=" + mailId + "&attid=0&disp=comp&safe=1&zw")
}

/* Add select all button */
var newButton = document.createElement("input")
var space = document.createTextNode(" ")
newButton.setAttribute("type", "button")
newButton.setAttribute("onClick", "window.selectAll()")
newButton.setAttribute("value", "Select All")
var form = document.querySelector("form td")
form.insertBefore(newButton, form.querySelector("select"))
form.insertBefore(space, form.querySelector("select"))

/* Add Download Selected button */
var menu = document.querySelector("form select")
menu.setAttribute("onchange", "window.selectChange(event)")
var separator = menu.querySelector("[disabled]")
var newButton = document.createElement("option")
newButton.setAttribute("value", "download_selected")
newButton.innerText = "Download Selected"
menu.insertBefore(newButton, separator)